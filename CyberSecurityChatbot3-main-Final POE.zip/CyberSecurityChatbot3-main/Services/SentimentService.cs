namespace CyberSecurityChatbot3.Services
{
    public class SentimentService
    {
        public string DetectSentiment(string message)
        {
            message = message.ToLower();

            if (message.Contains("happy"))
                return "happy";

            if (message.Contains("sad"))
                return "sad";

            if (message.Contains("stressed"))
                return "stressed";

            return "neutral";
        }
    }
}