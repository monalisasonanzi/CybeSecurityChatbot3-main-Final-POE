namespace CyberSecurityChatbot3.Models
{
    public class QuizQuestion
    {
        public string Question { get; set; }
        public string CorrectAnswer { get; set; }
    }
}